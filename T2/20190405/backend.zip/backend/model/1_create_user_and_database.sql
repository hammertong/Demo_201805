--
-- EXECUTE as MYSQL root
--

--
-- CREATE the DATABASE as root
--

CREATE DATABASE demo_huaweii_p30;

--
-- CREATE the USER and GRANT FULL ACCESS TO THE DATABASE 
--

SET GLOBAL validate_password_policy=LOW;

CREATE USER 'android'@'localhost' IDENTIFIED BY 'demo_201805';

GRANT ALL PRIVILEGES ON demo_huaweii_p30 . * TO 'android'@'localhost';

FLUSH PRIVILEGES;
