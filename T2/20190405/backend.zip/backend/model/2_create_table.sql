USE demo_huaweii_p30;

DROP TABLE IF EXISTS request;
CREATE TABLE request (
	requestId int(12) NOT NULL AUTO_INCREMENT COMMENT 'unique request id',
	command enum(
		'info',
		'status',
		'takePhoto', 
		'startMovie',
		'stopMovie',
		'switchCamera',
		'powerOn',
		'powerOff',
		'flipPage',
		'activate', 
		'zoom'
	) NOT NULL DEFAULT 'info' COMMENT 'Enumeration of all downstream commands',		
	payload varchar(64),
	publishTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	KEY requestId (requestId)
);

DROP TABLE IF EXISTS device;
CREATE TABLE device (
	deviceName varchar(16) UNIQUE NOT NULL COMMENT 'App managed name - using mac address of device',
	regisrationTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	lastAckPhotoId int(8),
	lastAckStartMovie int(8),
	lastAckStopkovie int(8),
	lastAckPowerOn int(8),
	lastAckPowerOff int(8),
	lastAckCameraFacing int(8),
	lastAckZoom int(8),
	lastAckFlipPage int(8),
	PRIMARY KEY (deviceName)
);

DROP TABLE IF EXISTS deviceStatus;
CREATE TABLE deviceStatus (
	deviceName varchar(16) NOT NULL,
	networkStatus enum('online', 'offline', 'timeout'),
	networkStatusTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	appStatus enum('pause', 'stop', 'resume', 'start', 'destroy'), 
	appStatusTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (deviceName)
	-- , FOREIGN KEY fk_device_id_info(deviceName)
	--	REFERENCES device(deviceName)
	--	ON UPDATE CASCADE
	--	ON DELETE RESTRICT	
);

DROP TABLE IF EXISTS deviceInfo;
CREATE TABLE deviceInfo (
	deviceName varchar(16) NOT NULL,	
	publishTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	payload varchar(256),
	PRIMARY KEY (deviceName)
	-- , FOREIGN KEY fk_device_id_info(deviceName)
	--	REFERENCES device(deviceName)
	--	ON UPDATE CASCADE
	--	ON DELETE RESTRICT
);

-- 
-- ACKNOWLEDGES MANAGEMENT 
-- 

DROP TABLE IF EXISTS ackPhoto; 
CREATE TABLE ackPhoto (
	id int(8) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	requestId int(12),
	deviceName varchar(16) NOT NULL,
	cameraId enum ('0', '1') NOT NULL,
	ackTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	result enum ('Success', 'Failure', 'Timeout' ) NOT NULL
);

DROP TABLE IF EXISTS ackStartMovie;
CREATE TABLE ackStartMovie (
	id int(8) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	requestId int(12),
	deviceName varchar(16) NOT NULL,
	cameraId enum ('0', '1') NOT NULL,
	ackTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	ackResult enum ('Success', 'Failure', 'Timeout') NOT NULL
);

DROP TABLE IF EXISTS ackStopMovie;
CREATE TABLE ackStopMovie (
	id int(8) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,	
	requestId int(12),
	deviceName varchar(16) NOT NULL,
	cameraId enum ('0', '1') NOT NULL,
	ackTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	ackResult enum ('Success', 'Failure', 'Timeout') NOT NULL
);

DROP TABLE IF EXISTS ackPowerOn;
CREATE TABLE ackPowerOn (
	id int(8) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,	
	requestId int(12),
	deviceName varchar(16) NOT NULL,
	ackTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	ackResult enum ('Success', 'Failure', 'Timeout') NOT NULL
);

DROP TABLE IF EXISTS ackPowerOff;
CREATE TABLE ackPowerOff (
	id int(8) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	requestId int(12),
	deviceName varchar(16) NOT NULL,
	ackTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	ackResult enum ('Success', 'Failure', 'Timeout') NOT NULL
);

DROP TABLE IF EXISTS ackCameraFacing;
CREATE TABLE ackCameraFacing (
	id int(8) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	requestId int(12),
	deviceName varchar(16) NOT NULL,
	cameraId enum ('0', '1') NOT NULL,
	ackTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, 
	ackResult enum ('Success', 'Failure', 'Timeout')
);

DROP TABLE IF EXISTS ackFlipPage;
CREATE TABLE ackFlipPage (
	id int(8) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	requestId int(12),
	deviceName varchar(16) NOT NULL,
	pageId int(2) NOT NULL,
	ackTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	ackResult enum ('Success', 'Failure', 'Timeout')
);

DROP TABLE IF EXISTS ackZoom;
CREATE TABLE ackZoom (
	id int(8) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	requestId int(12),
	deviceName varchar(16) NOT NULL,
	zoomLevelX float(3,1),
	zoomLevelY float(3,1),
	x float(3,1),
	y float(3,1),
	ackTime timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	ackResult enum ('Success', 'Failure', 'Timeout')
);



