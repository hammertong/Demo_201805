
DROP TRIGGER IF EXISTS after_ackPhoto_insert;
DROP TRIGGER IF EXISTS after_ackStartMovie_insert;
DROP TRIGGER IF EXISTS after_ackStopMovie_insert;
DROP TRIGGER IF EXISTS after_ackPowerOn_insert;
DROP TRIGGER IF EXISTS after_ackPowerOff_insert;
DROP TRIGGER IF EXISTS after_ackCameraFacing_insert;
DROP TRIGGER IF EXISTS after_ackZoom_insert;
DROP TRIGGER IF EXISTS after_ackFlipPage_insert;

DELIMITER $$
CREATE TRIGGER after_ackPhoto_insert 
    AFTER INSERT ON ackPhoto
    FOR EACH ROW 
BEGIN
    UPDATE device
    SET lastAckPhotoId = NEW.id
    WHERE deviceName = NEW.deviceName; 
END$$
DELIMITER 

DELIMITER $$
CREATE TRIGGER after_ackStartMovie_insert 
    AFTER INSERT ON ackStartMovie
    FOR EACH ROW 
BEGIN
    UPDATE device
    SET lastAckStartMovieId = NEW.id
    WHERE deviceName = NEW.deviceName; 
END$$

DELIMITER $$
CREATE TRIGGER after_ackStopMovie_insert 
    AFTER INSERT ON ackStopMovie
    FOR EACH ROW 
BEGIN
    UPDATE device
    SET lastAckStopkMovie = NEW.id
    WHERE deviceName = NEW.deviceName; 
END$$

DELIMITER $$
CREATE TRIGGER after_ackPowerOn_insert 
    AFTER INSERT ON ackPowerOn
    FOR EACH ROW 
BEGIN
    UPDATE device
    SET lastAckPowerOnId = NEW.id
    WHERE deviceName = NEW.deviceName; 
END$$

DELIMITER $$
CREATE TRIGGER after_ackPowerOff_insert 
    AFTER INSERT ON ackPowerOff
    FOR EACH ROW 
BEGIN
    UPDATE device
    SET lastAckPowerOffId = NEW.id
    WHERE deviceName = NEW.deviceName; 
END$$
DELIMITER

DELIMITER $$
CREATE TRIGGER after_ackCameraFacing_insert 
    AFTER INSERT ON ackCameraFacing
    FOR EACH ROW 
BEGIN
    UPDATE device
    SET lastAckCameraFacing = NEW.id
    WHERE deviceName = NEW.deviceName; 
END$$
DELIMITER

DELIMITER $$
CREATE TRIGGER after_ackZoom_insert 
    AFTER INSERT ON ackZoom
    FOR EACH ROW 
BEGIN
    UPDATE device
    SET lastAckZoom = NEW.id
    WHERE deviceName = NEW.deviceName; 
END$$
DELIMITER

DELIMITER $$
CREATE TRIGGER after_ackFlipPage_insert 
    AFTER INSERT ON ackFlipPage
    FOR EACH ROW 
BEGIN
    UPDATE device
    SET lastAckFlipPage = NEW.id
    WHERE deviceName = NEW.deviceName; 
END$$


