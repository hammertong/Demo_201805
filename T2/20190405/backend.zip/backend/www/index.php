<?php

//
// backend controller 
//

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="shortcut icon" type="image/ico" href="images/favicon.ico">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta http-equiv="Content-type" content="text/html;charset=UTF-8">
    <meta name="description" content="Android synoptic satus report">

    <title>Android status report</title>

    <link rel="stylesheet" type="text/css" href="lib/jquery.dataTables.css"> 
    <link rel="stylesheet" type="text/css" href="lib/select.dataTables.min.css"> 
    <link rel="stylesheet" type="text/css" href="lib/buttons.dataTables.min.css">  
    <link rel="stylesheet" type="text/css" href="lib/shCore.css">
    <link rel="stylesheet" type="text/css" href="lib/demo.css">
      
    <script type="text/javascript" language="javascript" src="lib/jquery-3.3.1.js"></script>
    <script type="text/javascript" language="javascript" src="lib/jquery.dataTables.js"></script>
    <script type="text/javascript" language="javascript" src="lib/dataTables.select.min.js"></script>
    <script type="text/javascript" language="javascript" src="lib/dataTables.buttons.min.js"></script>
    <script type="text/javascript" language="javascript" src="lib/shCore.js"></script>
    <script type="text/javascript" language="javascript" src="lib/demo.js"></script>

    <link rel="stylesheet" href="lib/jquery-ui.css">
    <script src="lib/jquery-ui.js"></script>

    <style class="init">
      /* http://api.jqueryui.com/menu/ */
      .ui-menu { 
        margin-top: 30px;   
        width: 180px; 
        border: 0px;    
      }
      /* local management */
      .main-pane {
        width: 100%;
        border: 0px;
      }
      .left-pane {
        width: 190px;
        vertical-align: top;
      }
      .right-pane {
        width: 100%;
        vertical-align: top;
      }
    </style>

    <script type="text/javascript">

      var dataTable = null;

      //
      // SHOW MODAL DIALOG
      //
      
      function popup() {        
        $( "#dialog" ).dialog({
          resizable: false,
          height: "auto",
          width: 400,
          modal: true,
          buttons: {
            "Conferma": function() {
              console.log("selected confirm");
              $( this ).dialog( "close" );
              /*  
              $.ajax({
                url: "data/?p=1",
                success: function(data) {
                  console.log("action success: " + JSON.stringify(data));
                },
                error: function(data) {
                  console.log("action error");
                }           
              });
              */
            },
            "Annulla": function() {
              console.log("selected cancel");
              $( this ).dialog( "close" );
            }
          }
        });
      }

      //
      // INITIALIZE COMPONENTS WHEN DOCUMENT IS READY
      //
            
      $(document).ready(function() {

        //
        // DIRECT AJAX INVOCATION
        //
        /*
        $.ajax(
        {
          "type": "POST",       
          "url": "data/",               
          "data" : {
            "field1": "value 1",    
            "field2": "value 2",    
          },        
          success: function (data) {                                
          },
          error: function(data) {            
          }
        });
        */

        //
        // DATA TABLE INITIALIZATION
        //
        var events = $('#events');
        var table = $('#results').DataTable( {        
          "ajax": {
              "url": "data/",
              "type": "POST",
              "data" : {
                "field1": "value 1",                    
                "field2": "value 2",                    
              },
              "language": {
                "lengthMenu": "Visualizza _MENU_ linee per pagina",
                "zeroRecords": "Nessun dato trovato - spiacenti.",
                "info": "Visualizza pagina _PAGE_ di _PAGES_",
                "infoEmpty": "Nessun dispositivo trovato",
                "infoFiltered": "(filtrati da un totale di _MAX_ linee)",
                "search": "cerca",
                "sLoadingRecords": "Caricamento...",
                "sProcessing": "Elaborazione...",
                "sSearch": "Cerca:",
                "sZeroRecords": "La ricerca non ha portato alcun risultato.",
                "oPaginate": {
                  "sFirst": "Inizio",
                  "sPrevious": "Precedente",
                  "sNext": "Successivo",
                  "sLast": "Fine"
                },
                "oAria": {
                  "sSortAscending": "attiva per ordinare la colonna in ordine crescente",
                  "sSortDescending": "attiva per ordinare la colonna in ordine decrescente"
                }
              }
          },
          "columnDefs": [ {
              "searchable": false,
              "orderable": false,
              "render": function ( data, type, row ) {
                //return data +' ('+ row[3]+')';
                if (data == 'on') {
                  return '<img src="images/green.png" alt="on" style="border: 0px; width: 20px;">';
                }
                else {
                  return '<img src="images/red.png" alt="off" style="border: 0px; width: 20px;">';
                }
              },
              "targets": 0
            }

          ],     
          select: true
        });  

        dataTable = table;

        /*
        table.on( 'order.dt search.dt', function () {
            table.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
                //console.log("row index " + i);
                debugger;                
            } );
        } ).draw(); 
        */ 

        //
        // ON CELL CLICK LISTENER
        //
        /*
        $('#results tbody').on( 'click', 'td', function () {
          var c = table.cell( this ).index().column;
          if (c == 2) { //clicked col 2
              var value = table.cell( this ).data();         
              //.. do something with value here ...              
          }
        });
        */

        //
        // INIT AUTOCOMPLETE TEXT BOX
        //
        /*
        var source = [ "pippo", "pluto", "paperino" ];
        $( "#tags" ).autocomplete({     
          minLength: 2,
          source: source,
          select: function(event, ui) {
            //var label = ui.item.label;
            var value = ui.item.value;
            document.location.href = '../tool-ureq/?user=' + value;
            //$('#success').html(label + ' - ' + value);
          }
        });
        */

        //
        // INITIALIZE MENU
        //
        $( "#menu" ).menu();

      });


      function updateRow ( findValue, findColumn, updatedRow ) {
        var updated = false;
        //https://datatables.net/reference/api/
        dataTable.rows().eq(0).each( function ( index ) {
            var row = dataTable.row( index );         
            var data = row.data();
            if (data[ findColumn ] == findValue ) {
              //debugger;
              dataTable
                  .row( index )
                  .data( updatedRow );
               dataTable
                  .row( index )
                  .invalidate()
                  .draw();
                updated = true;
            }            
        });
        if (!updated) {
          dataTable.row.add( [ 'off', 'new', findValue, 'new', 'new', 'new', 'new'] ).draw();
        }
      }

    </script>
  </head>

  <body>    

    <!--CONFIRM DIALOG BOX -->    

    <div id="dialog" title="Avviso" style="display:none;">
      <p id="dialogMessage">Procedere con l'operazione selezionata?</p>
    </div>

    <table class="main-pane">

      <tr>
        
        <td class="left-pane">  

          <!-- BEGIN MENU -->    

          <ul id="menu">
            <li class="ui-state-disabled"><div>Android Controls</div></li>
            <li><div>Record Start</div></li>
            <li><div>Record Stop</div></li>
            <li><div>Take Photo</div></li>
            <li><div>Switch Camera</div>
              <ul>
                <li class="ui-state-disabled"><div>Available Cameras</div></li>
                <li><div>Back Facing</div></li>
                <li><div>Front Facing</div></li>
              </ul>
            </li>
            <li><div onclick="updateRow('-RoyBoy not found-', 2, [ 'off', 'new', '-RoyBoyx-', 'new', 'new', 'new', 'new' ] )">Wake On</div></li>
            <li><div onclick="updateRow('-RoyBoy-', 2, [ 'off', 'changed', '-RoyBoy-', 'changed', 'changed', 'changed', 'changed' ] )">Wake Off</div></li>
            <li><div>Switch Page</div>
              <ul>
                  <li><div>Page 1</div></li>
                  <li><div>Page 2</div></li>
                  <li><div>Page 3</div></li>
                  <li><div>Page 4</div></li>
              </ul>
            </li>
            <li class="ui-state-disabled"><div>Specials (n/a)</div></li>
          </ul>

          <!-- END MENU -->

        </td> <!-- end left pane -->

        <td class="right-pane">

          <!--
          <div class="ui-widget" style="margin-top: 10px;">
            <label for="tags">Username: </label>
            <input id="tags" placeholder="search username ...">
          </div>
          -->

          <div class="container">
            
            <h1>Status report<span> - smartphones list</span></h1>

              <table id="results" class="display" style="width:100%">
                <thead>
                  <tr>     
                    <th></th>     
                    <th>userid</th>
                    <th>username</th>
                    <th>email</th>
                    <th>registration date</th>
                    <th>country</th>
                    <th>src_app</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>       
                    <th></th>             
                    <th>userid</th>
                    <th>username</th>
                    <th>email</th>
                    <th>registration date</th>
                    <th>country</th>
                    <th>src_app</th>
                  </tr>
                </tfoot>
              </table>  

          </div>    

        </td> <!-- end right pane -->

      </tr>

    </table> <!-- end main-pane -->

  </body>
  
</html>
