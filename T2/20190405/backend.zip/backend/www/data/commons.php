<?php

/**
 * database connectivity 
 *
 */
define ('DB_HOST', "localhost");
define ('DB_NAME', "demo_huaweii_p30");
define ('DB_USER', "android");
define ('DB_PASS', "demo_201805");

/**
 * function used o fit data of an SQL  query into json response
 * requested by jquery data table
 *
 */
function fitDataTable ( $result ) {
	$j = 0;
	$data = array();
	foreach ($result as $row) {
		$entry = array();
		$i = 0;
		foreach ($row as $key => $value) {
			$entry[$i++] = $value;
		}
		$data[$j++] = $entry;
	}
	return array ( "data" => $data );
}

?>
